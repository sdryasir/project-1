import Footer from './footer';
function footer() {
    return (
        <Footer />
    )
}
export default footer;