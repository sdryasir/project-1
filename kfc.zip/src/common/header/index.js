import Header from './header';

function header() {
    return (
        <Header />
    )
}
export default header;