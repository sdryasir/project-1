import CardList from "../collections/cardlisting";
import Slider from "./slider";

function Home() {
    return (
        <>
            <Slider />
            <CardList />
        </>
    )
}

export default Home;