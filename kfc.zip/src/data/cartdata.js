export const cartData = [
    {
        id: 1,
        title: "Krunch Burger ",
        image: "/images/products/Bone-kfc.png",
        description: "Enjoy the crispy chicken fillet in a soft bun with spicy mayo and our signature sauce with fresh lettuce.",
        price: 195,
        stock: 10,
        qty: 1
    },
    {
        id: 2,
        title: "Krunch Burger with Drink ",
        image: "/images/products/Chicken-kfc.png",
        description: "Krunch burger with a regular drink.",
        price: 265,
        stock: 3,
        qty: 3
    },

]