export const sliderdata = [
    {
        id: 1,
        image: "/images/slider/hm-slider-1.png",
        caption: ""
    },
    {
        id: 2,
        image: "/images/slider/hm-slider-2.png",
        caption: ""
    },
    {
        id: 3,
        image: "/images/slider/hm-slider-3.jpg",
        caption: ""
    }
]